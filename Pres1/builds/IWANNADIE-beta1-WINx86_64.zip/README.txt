Thanks for downloading I WANNA DIE-beta1 for Windows x86_64 platform. Before you can play, we need you to make sure of certain points :
	- make sure you unzipped the archive. If you could read this file while its stille zipped, it won't work as good with the executable!
	- make sure the executable "IWANNADIE-beta1-WINx86_64.exe" is placed in the same folder as the folder "IWANNADIE-beta1-WINx86_64_DATA"
	- when launching the game for the first time, Unity will ask for Internet access, but we don't need it at the moment, so answer whatever you want and click OK
	- when launching the game, Unity will ask you to configure graphics and inputs. Inputs are made for azerty keyboards, so if you don't want to use one, you might need to change the keymap.

WARNING: game keymap is not the same as in-game text. The game keymap can be changed at the beginning of the game, but textual in-game informations are hard coded and will always match the default keymap. Don't worry, this might be changed in the future

If you encounter a bug, please report it at http://suicide-squad.esy.es/?go=bugreport

To keep updated about the game, please visit our website suicide-squad.esy.es

 - The Suicide Squad (2015)
