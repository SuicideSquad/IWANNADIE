Thanks for downloading I WANNA DIE-beta1.1. Before you can play, we need you to make sure of certain points :
	- make sure you unzipped the archive. If you could read this file while its stille zipped, it won't work as well with the executable!
	- make sure the executable is in the same folder as the "Data" folder (does not apply for MacOSX)
	- when launching the game, Unity will ask you to configure graphics and inputs. Unless you know what you are doing, we recommend playing in windowed mode, with a lower resolution than that of your screen. Inputs are made for azerty keyboards, so if you don't want to use one, you might need to change the keymap.
	- if you did not listen to us and are blocked in the game, press Escape to quit the game (unless you changed this key in the Unity Inputs menu)

WARNING: game keymap is not the same as in-game text. The game keymap can be changed at the beginning of the game, but textual in-game informations are hard coded and will always match the default keymap. Don't worry, this might be changed in the future

If you encounter a bug, please report it at http://suicide-squad.esy.es/?go=bugreport

To keep updated about the game, please visit our website suicide-squad.esy.es

 - The Suicide Squad (2015)
